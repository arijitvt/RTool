
#include <stdio.h>
#include <unistd.h>
/* The "original" function */

void actual ( void )
{
  printf("in actual-so\n");
}

