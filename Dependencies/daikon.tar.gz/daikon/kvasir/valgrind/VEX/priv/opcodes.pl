#!/usr/bin/env perl

use v5.14;    #to get given/when

use strict;
use Text::ParseWords;

my @tokens;
my $need = 0;
my $opcode = "";

sub print_opcode {
    if ($need & 3) {
        print "$opcode needed\n";
    } else {
        print "$opcode only used by ";
        if ($need & 4)  { print "arm ";}
        if ($need & 8)  { print "mips ";}
        if ($need & 16) { print "ppc ";}
        if ($need & 32) { print "s390 ";}
        print "\n";
    }
}

while (<>) {

    @tokens = quotewords('\s+', 1, $_);

    # debugging output
    # print "orig: $tokens[1]  $tokens[0] \n";

    if ($opcode ne $tokens[0]) {
        if ($need > 0) {
            print_opcode;
        }
        $opcode = $tokens[0];
        $need = 0;
    }

    given ($tokens[1]) {
        when ("arm") {
            $need |= 4;
        }
        when ("amd64") {
            $need |= 1;
        }
        when ("mips") {
            $need |= 8;
        }
        when ("ppc") {
            $need |= 16;
        }
        when ("s390") {
            $need |= 32;
        }
        when ("x86") {
            $need |= 2;
        }
        default {
            print STDERR "Unrecognized machine type $tokens[1] at line ", $. + 1, "\n";
        }
    }
}

if ($need > 0) {
    print_opcode;
}
